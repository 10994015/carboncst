<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
  <div class="home" id="home">
    <div class="banners">
      <a href="javascript:;"><img src="/images/img2.jpg" alt=""></a>
      <a href="javascript:;"><img src="/images/img1.jpg" alt=""></a>
    </div>

    <section class="news">
      <div class="title">
        <img src="/images/CST Logo.png" alt="臺灣碳材料學會" />
        <h2>最新消息 News</h2>
        <a href="/news" class="readmore">READ MORE...</a>
      </div>
      <div class="items">
        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="item">
          <div class="imgbox">
            <div class="light"></div>
            <img src="/images/news.jpg" alt="">
          </div>
          <div class="content">
            <span><?php if($article->category === 0): ?>會務公告 <?php else: ?> 徵才公告 <?php endif; ?></span>
            <a href="/news/<?php echo e($article->slug); ?>"><?php echo e($article->title); ?></a>
            <p>
              <?php echo nl2br($article->content) ?>
            </p>
            <small><?php echo e($article->updated_at); ?></small>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

    </section>
  </div>

  <?php $__env->startPush('scripts'); ?>
  <script>
    $(document).ready(function(){
      $('.banners').slick({
        dots: true,
        infinite: true,
        speed: 500,
        fade: true,
        cssEase: 'linear'
      });
    });
  </script>
  <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\User\Desktop\carbon\resources\views/home.blade.php ENDPATH**/ ?>