<div id="chairman-page">
    <section class="chairmans">
        <div class="title">
            <img src="/images/CST Logo.png" alt="臺灣碳材料學會" />
            <h2>理事長的話</h2>
        </div>
        <div class="content" x-data="{
            openText:function(ev){
                if(ev.target.tagName === 'P' || ev.target.tagName === 'H2'){
                    ev.target.parentNode.classList.toggle('active')
                    ev.target.parentNode.parentNode.querySelector('.text').classList.toggle('open')
                    return;
                }
                ev.target.classList.toggle('active')
                ev.target.parentNode.querySelector('.text').classList.toggle('open')
            }
        }">
            <?php $__currentLoopData = $chairmans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$chairman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <div class="chairman">
                <div class="title <?php if($i===0): ?> active <?php endif; ?>" x-on:click="openText($event)">
                    <h2><?php echo e($chairman->name); ?></h2>
                    <p><?php echo e($chairman->message_date); ?></p>
                </div>
                <div class="text <?php if($i===0): ?> open <?php endif; ?>">
                    <article>
                        <img src="<?php echo e($chairman->image); ?>" class="float-right" />
                        <?php echo nl2br($chairman->content) ?>
                    </article>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </section>
</div><?php /**PATH C:\Users\User\Desktop\carbon\resources\views/livewire/chairman-componet.blade.php ENDPATH**/ ?>