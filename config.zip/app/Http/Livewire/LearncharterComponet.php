<?php

namespace App\Http\Livewire;

use Livewire\Component;

class LearncharterComponet extends Component
{
    public function render()
    {
        return view('livewire.learncharter-componet');
    }
}
