<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div id="news-page">
        <section class="news">
            <div class="title">
                <img src="/images/CST Logo.png" alt="臺灣碳材料學會" />
                <h2>最新消息 News</h2>
                <label for="">
                    <input type="text" placeholder="搜尋..." />
                    <button>
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                            stroke="currentColor" class="w-5 h-5">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
                        </svg>
                    </button>
                </label>
            </div>
            <div class="items">
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item">
                    <div class="imgbox">
                        <div class="light"></div>
                        <?php if($article->image): ?>
                        <img src="/images/<?php echo e($article->image); ?>" alt="<?php echo e($article->title); ?>">
                        <?php else: ?>
                        <img src="/images/news.jpg" alt="<?php echo e($article->title); ?>">
                        <?php endif; ?>
                    </div>
                    <div class="content">
                        <span><?php if($article->category==0): ?> 會務公告 <?php else: ?> 徵才公告 <?php endif; ?></span>
                        <a href="/news/<?php echo e($article->slug); ?>"><?php echo e($article->title); ?></a>
                        <p>
                            <?php echo nl2br($article->content) ?>
                        </p>
                        <small><?php echo e($article->updated_at); ?></small>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <?php echo e($articles->links()); ?>

        </section>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\User\Desktop\carbon\resources\views/news.blade.php ENDPATH**/ ?>