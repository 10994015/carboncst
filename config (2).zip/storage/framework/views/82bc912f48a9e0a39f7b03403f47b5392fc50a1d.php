<div id="cstdatabase-page">
    <section class="cstdatabase">
        <div class="title">
            <img src="/images/CST Logo.png" alt="臺灣碳材料學會" />
            <h2>碳材資料庫</h2>
        </div>
        <div class="content">
            <table>
                <thead>
                    <tr>
                        <th>姓名</th>
                        <th>服務單位</th>
                        <th>職稱</th>
                        <th>研究領域</th>
                        <th>相關連結</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $databases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $database): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($database->name); ?></td>
                        <td><?php echo e($database->units); ?></td>
                        <td><?php echo e($database->job_title); ?></td>
                        <td>
                            <?php echo e($database->field); ?>

                        </td>
                        <td>
                            <div class="link-group">
                                <?php if($database->button_1): ?>
                                <a
                                    href="<?php if(strtolower($database->button_1)==='email'): ?> mailto:<?php echo e($database->link_1); ?> <?php else: ?> <?php echo e($database->link_1); ?> <?php endif; ?>"><?php echo e($database->button_1); ?></a>
                                <?php endif; ?>
                                <?php if($database->button_2): ?>
                                <a
                                    href="<?php if(strtolower($database->button_2)==='email'): ?> mailto:<?php echo e($database->link_2); ?> <?php else: ?> <?php echo e($database->link_2); ?> <?php endif; ?>"><?php echo e($database->button_2); ?></a>
                                <?php endif; ?>
                                <?php if($database->button_3): ?>
                                <a
                                    href="<?php if(strtolower($database->button_3)==='email'): ?> mailto:<?php echo e($database->link_3); ?> <?php else: ?> <?php echo e($database->link_3); ?> <?php endif; ?>"><?php echo e($database->button_3); ?></a>
                                <?php endif; ?>
                                <?php if($database->button_4): ?>
                                <a
                                    href="<?php if(strtolower($database->button_4)==='email'): ?> mailto:<?php echo e($database->link_4); ?> <?php else: ?> <?php echo e($database->link_4); ?> <?php endif; ?>"><?php echo e($database->button_4); ?></a>
                                <?php endif; ?>
                                <?php if($database->button_5): ?>
                                <a
                                    href="<?php if(strtolower($database->button_5)==='email'): ?> mailto:<?php echo e($database->link_5); ?> <?php else: ?> <?php echo e($database->link_5); ?> <?php endif; ?>"><?php echo e($database->button_5); ?></a>
                                <?php endif; ?>

                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </section>
</div><?php /**PATH C:\Users\User\Desktop\carbon\resources\views/livewire/cst-database-component.blade.php ENDPATH**/ ?>