<div id="news-page">
    <section class="news">
        <div class="title">
            <img src="/images/CST Logo.png" alt="臺灣碳材料學會" />
            <h2>最新消息</h2>
            <label for="">
                <input type="text" placeholder="搜尋..." wire:model="inputText" />
                <button wire:click='searchFn'>
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                        stroke="currentColor" class="w-5 h-5">
                        <path stroke-linecap="round" stroke-linejoin="round"
                            d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
                    </svg>
                </button>
            </label>
        </div>
        <div class="items">
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item">
                <div class="imgbox">
                    <div class="light"></div>
                    <?php if($article->image): ?>
                    <img src="<?php echo e($article->image); ?>" alt="<?php echo e($article->title); ?>">
                    <?php else: ?>
                    <img src="/images/news.jpg" alt="<?php echo e($article->title); ?>">
                    <?php endif; ?>
                </div>
                <div class="content">
                    <span><?php if($article->category==0): ?> 會務公告 <?php else: ?> 徵才公告 <?php endif; ?></span>
                    <a href="javascript:;"><?php echo e($article->title); ?></a>
                    <p>
                        <?php echo nl2br($article->content) ?>
                    </p>
                    <small><?php echo e($article->updated_at); ?></small>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <?php echo e($articles->links()); ?>

    </section>

</div><?php /**PATH C:\Users\User\Desktop\carbon\resources\views/livewire/news-componet.blade.php ENDPATH**/ ?>