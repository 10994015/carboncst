<div id="forum-page">
    <section class="forum">
        <div class="title">
            <img src="/images/CST Logo.png" alt="臺灣碳材料學會" />
            <h2>碳材料論壇</h2>
        </div>
        <div class="content" x-data="{
            openText:function(ev){
                if(ev.target.tagName === 'P' || ev.target.tagName === 'H2'){
                    ev.target.parentNode.classList.toggle('active')
                    ev.target.parentNode.parentNode.querySelector('.text').classList.toggle('open')
                    return;
                }
                ev.target.classList.toggle('active')
                ev.target.parentNode.querySelector('.text').classList.toggle('open')
            }
        }">
            <?php $__currentLoopData = $forums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$forum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="chairman">
                <div class="title <?php if($i===0): ?> active <?php endif; ?>" x-on:click="openText($event)">
                    <h2><?php echo e($forum->title); ?></h2>
                </div>
                <div class="text <?php if($i===0): ?> open <?php endif; ?>">
                    <article>
                        <div class="link-group">
                            <?php if($forum->button_1): ?>
                            <a href="<?php echo e($forum->link_1); ?>"> <?php echo e($forum->button_1); ?> </a>
                            <?php endif; ?>
                            <?php if($forum->button_2): ?>
                            <a href="<?php echo e($forum->link_2); ?>"> <?php echo e($forum->button_2); ?> </a>
                            <?php endif; ?>
                            <?php if($forum->button_3): ?>
                            <a href="<?php echo e($forum->link_3); ?>"> <?php echo e($forum->button_3); ?> </a>
                            <?php endif; ?>
                            <?php if($forum->button_4): ?>
                            <a href="<?php echo e($forum->link_4); ?>"> <?php echo e($forum->button_4); ?> </a>
                            <?php endif; ?>
                            <?php if($forum->button_5): ?>
                            <a href="<?php echo e($forum->link_5); ?>"> <?php echo e($forum->button_5); ?> </a>
                            <?php endif; ?>
                        </div>
                        <?php echo e($forum->content); ?>

                        <img src="<?php echo e($forum->image); ?>" />
                    </article>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </section>
</div><?php /**PATH C:\Users\User\Desktop\carbon\resources\views/livewire/forum-component.blade.php ENDPATH**/ ?>